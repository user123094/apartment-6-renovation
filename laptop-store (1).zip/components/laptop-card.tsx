'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { Laptop } from '@/lib/data'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'

interface LaptopCardProps {
  laptop: Laptop;
  searchQuery?: string;
}

export function LaptopCard({ laptop, searchQuery = '' }: LaptopCardProps) {
  const [cartItems, setCartItems] = useState<Laptop[]>([])

  useEffect(() => {
    const storedItems = localStorage.getItem('cartItems')
    if (storedItems) {
      setCartItems(JSON.parse(storedItems))
    }
  }, [])

  const addToCart = (laptop: Laptop) => {
    const updatedCart = [...cartItems, laptop]
    setCartItems(updatedCart)
    localStorage.setItem('cartItems', JSON.stringify(updatedCart))
  }

  const highlightText = (text: string) => {
    if (!searchQuery) return text

    const parts = text.split(new RegExp(`(${searchQuery})`, 'gi'))
    return parts.map((part, index) => 
      part.toLowerCase() === searchQuery.toLowerCase() ? 
        <span key={index} className="bg-yellow-200">{part}</span> : part
    )
  }

  return (
    <Card className="w-full max-w-sm">
      <CardHeader>
        <CardTitle>{highlightText(laptop.name)}</CardTitle>
      </CardHeader>
      <CardContent>
        <Link href={`/product/${laptop.id}`} className="block mb-4">
          <Image
            src={laptop.image}
            alt={laptop.name}
            width={300}
            height={200}
            className="w-full h-48 object-cover rounded-md transition-transform hover:scale-105"
          />
        </Link>
        <p className="text-sm text-gray-600 mb-2">{highlightText(laptop.description)}</p>
        <p className="text-lg font-bold">${laptop.price.toFixed(2)}</p>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button asChild variant="outline">
          <Link href={`/product/${laptop.id}`}>View Details</Link>
        </Button>
        <Button onClick={() => addToCart(laptop)}>
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  )
}

