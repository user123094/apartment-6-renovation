import { Review } from '@/lib/data'
import { ReviewItem } from './review-item'
import { StarRating } from './star-rating'

interface ReviewsSectionProps {
  reviews: Review[];
}

export function ReviewsSection({ reviews }: ReviewsSectionProps) {
  const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length;

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold mb-4">Customer Reviews</h2>
      <div className="flex items-center mb-4">
        <StarRating rating={averageRating} />
        <span className="ml-2 text-sm text-gray-600">
          Based on {reviews.length} review{reviews.length !== 1 ? 's' : ''}
        </span>
      </div>
      <div className="space-y-4">
        {reviews.map((review) => (
          <ReviewItem key={review.id} review={review} />
        ))}
      </div>
    </div>
  )
}

