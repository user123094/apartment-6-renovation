'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Laptop } from '@/lib/data'
import { Button } from '@/components/ui/button'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'

interface CartProps {
  initialItems: Laptop[];
  onRemoveFromCart: (id: number) => void;
}

export function Cart({ initialItems, onRemoveFromCart }: CartProps) {
  const [items, setItems] = useState(initialItems)
  const router = useRouter()

  useEffect(() => {
    const storedItems = localStorage.getItem('cartItems')
    if (storedItems) {
      setItems(JSON.parse(storedItems))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('cartItems', JSON.stringify(items))
  }, [items])

  const total = items.reduce((sum, item) => sum + item.price, 0)

  const handleRemoveFromCart = (id: number) => {
    setItems(prevItems => prevItems.filter(item => item.id !== id))
    onRemoveFromCart(id)
  }

  const handleCheckout = () => {
    router.push('/checkout')
  }

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">
          Cart ({items.length})
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Your Cart</SheetTitle>
          <SheetDescription>
            You have {items.length} item(s) in your cart
          </SheetDescription>
        </SheetHeader>
        <div className="mt-4">
          {items.map((item) => (
            <div key={item.id} className="flex justify-between items-center mb-2">
              <span>{item.name}</span>
              <span>${item.price.toFixed(2)}</span>
              <Button variant="destructive" size="sm" onClick={() => handleRemoveFromCart(item.id)}>
                Remove
              </Button>
            </div>
          ))}
        </div>
        <div className="mt-4 text-right">
          <strong>Total: ${total.toFixed(2)}</strong>
        </div>
        <div className="mt-4">
          <Button onClick={handleCheckout} className="w-full">
            Proceed to Checkout
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}

