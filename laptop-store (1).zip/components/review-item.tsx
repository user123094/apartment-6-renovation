import { Review } from '@/lib/data'
import { StarRating } from './star-rating'

interface ReviewItemProps {
  review: Review;
}

export function ReviewItem({ review }: ReviewItemProps) {
  return (
    <div className="border-b border-gray-200 py-4">
      <div className="flex items-center justify-between mb-2">
        <div className="font-semibold">{review.username}</div>
        <div className="text-sm text-gray-500">{review.date}</div>
      </div>
      <StarRating rating={review.rating} />
      <p className="mt-2 text-gray-700">{review.comment}</p>
    </div>
  )
}

