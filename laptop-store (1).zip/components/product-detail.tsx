import Image from 'next/image'
import { Laptop } from '@/lib/data'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { ReviewsSection } from './reviews-section'

interface ProductDetailProps {
  laptop: Laptop
  onAddToCart: (laptop: Laptop) => void
}

export function ProductDetail({ laptop, onAddToCart }: ProductDetailProps) {
  return (
    <div className="space-y-8">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-3xl">{laptop.name}</CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-6">
          <div>
            <Image
              src={laptop.image.replace('200&width=300', '400&width=600')}
              alt={laptop.name}
              width={600}
              height={400}
              className="w-full rounded-lg shadow-md"
            />
          </div>
          <div className="space-y-4">
            <p className="text-lg">{laptop.description}</p>
            <div className="text-2xl font-bold">${laptop.price.toFixed(2)}</div>
            <div className="space-y-2">
              <h3 className="font-semibold">Specifications:</h3>
              <ul className="list-disc list-inside space-y-1">
                <li>Processor: {laptop.specs.processor}</li>
                <li>RAM: {laptop.specs.ram}</li>
                <li>Storage: {laptop.specs.storage}</li>
                <li>Display: {laptop.specs.display}</li>
              </ul>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={() => onAddToCart(laptop)} className="w-full">
            Add to Cart
          </Button>
        </CardFooter>
      </Card>
      <ReviewsSection reviews={laptop.reviews} />
    </div>
  )
}

