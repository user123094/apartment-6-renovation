'use client'

import { useState } from 'react'
import { laptops } from '@/lib/data'
import { LaptopCard } from '@/components/laptop-card'
import { Cart } from '@/components/cart'
import { getUser } from '@/lib/auth'
import { Button } from '@/components/ui/button'
import { SearchBar } from '@/components/search-bar'
import Link from 'next/link'

export default function Home() {
  const user = getUser()
  const [searchQuery, setSearchQuery] = useState('')

  const filteredLaptops = laptops.filter(laptop =>
    laptop.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    laptop.description.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="container mx-auto px-4 py-8">
      <header className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
        <h1 className="text-3xl font-bold">Laptop Store</h1>
        <div className="flex items-center space-x-4">
          {user ? (
            <>
              <span>Welcome, {user.email}</span>
              <Cart initialItems={[]} onRemoveFromCart={() => {}} />
              <form action="/api/auth/signout" method="POST">
                <Button type="submit" variant="outline">Sign Out</Button>
              </form>
            </>
          ) : (
            <>
              <Button asChild variant="outline">
                <Link href="/signin">Sign In</Link>
              </Button>
              <Button asChild>
                <Link href="/signup">Sign Up</Link>
              </Button>
            </>
          )}
        </div>
      </header>
      <div className="mb-8 max-w-md mx-auto">
        <SearchBar onSearch={setSearchQuery} />
      </div>
      {filteredLaptops.length === 0 ? (
        <p className="text-center text-gray-500">No laptops found matching your search.</p>
      ) : (
        <main className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredLaptops.map((laptop) => (
            <LaptopCard key={laptop.id} laptop={laptop} />
          ))}
        </main>
      )}
    </div>
  )
}

