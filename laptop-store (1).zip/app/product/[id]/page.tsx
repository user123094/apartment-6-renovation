'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { laptops, Laptop } from '@/lib/data'
import { ProductDetail } from '@/components/product-detail'
import { Button } from '@/components/ui/button'

export default function ProductPage() {
  const { id } = useParams()
  const [cartItems, setCartItems] = useState<Laptop[]>([])

  useEffect(() => {
    const storedItems = localStorage.getItem('cartItems')
    if (storedItems) {
      setCartItems(JSON.parse(storedItems))
    }
  }, [])

  const laptop = laptops.find(l => l.id === Number(id))

  if (!laptop) {
    return <div>Product not found</div>
  }

  const addToCart = (laptop: Laptop) => {
    const updatedCart = [...cartItems, laptop]
    setCartItems(updatedCart)
    localStorage.setItem('cartItems', JSON.stringify(updatedCart))
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Button asChild variant="outline">
          <Link href="/">← Back to All Products</Link>
        </Button>
      </div>
      <ProductDetail laptop={laptop} onAddToCart={addToCart} />
    </div>
  )
}

