import { hash, compare } from 'bcrypt';
import { sign, verify } from 'jsonwebtoken';
import { cookies } from 'next/headers';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

export interface User {
  id: number;
  email: string;
  password: string;
}

// This is a mock database. In a real application, you'd use a proper database.
let users: User[] = [];

export async function signUp(email: string, password: string): Promise<User | null> {
  const existingUser = users.find(user => user.email === email);
  if (existingUser) {
    return null;
  }

  const hashedPassword = await hash(password, 10);
  const newUser: User = { id: users.length + 1, email, password: hashedPassword };
  users.push(newUser);
  return newUser;
}

export async function signIn(email: string, password: string): Promise<User | null> {
  const user = users.find(user => user.email === email);
  if (!user) {
    return null;
  }

  const passwordMatch = await compare(password, user.password);
  if (!passwordMatch) {
    return null;
  }

  return user;
}

export function createToken(user: User): string {
  return sign({ userId: user.id }, JWT_SECRET, { expiresIn: '1h' });
}

export function verifyToken(token: string): { userId: number } | null {
  try {
    return verify(token, JWT_SECRET) as { userId: number };
  } catch {
    return null;
  }
}

export function getUser(): User | null {
  const token = cookies().get('token')?.value;
  if (!token) {
    return null;
  }

  const payload = verifyToken(token);
  if (!payload) {
    return null;
  }

  return users.find(user => user.id === payload.userId) || null;
}

