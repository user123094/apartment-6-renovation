export interface Review {
  id: number;
  userId: number;
  username: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Laptop {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  specs: {
    processor: string;
    ram: string;
    storage: string;
    display: string;
  };
  reviews: Review[];
  tags: string[];
}

export const laptops: Laptop[] = [
  {
    id: 1,
    name: "UltraBook Pro",
    description: "Powerful and lightweight laptop for professionals",
    price: 1299.99,
    image: "/placeholder.svg?height=200&width=300",
    specs: {
      processor: "Intel Core i7-1165G7",
      ram: "16GB DDR4",
      storage: "512GB NVMe SSD",
      display: "14-inch 4K IPS",
    },
    reviews: [
      {
        id: 1,
        userId: 1,
        username: "TechEnthusiast",
        rating: 5,
        comment: "This laptop is amazing! It's fast, lightweight, and the battery life is incredible.",
        date: "2023-05-15",
      },
      {
        id: 2,
        userId: 2,
        username: "ProductivityGuru",
        rating: 4,
        comment: "Great for work and multitasking. The only downside is the fan can get a bit noisy under heavy load.",
        date: "2023-06-02",
      },
    ],
    tags: ["ultrabook", "professional", "lightweight", "powerful"],
  },
  {
    id: 2,
    name: "GamerX Elite",
    description: "High-performance gaming laptop with RTX graphics",
    price: 1799.99,
    image: "/placeholder.svg?height=200&width=300",
    specs: {
      processor: "AMD Ryzen 9 5900HX",
      ram: "32GB DDR4",
      storage: "1TB NVMe SSD",
      display: "15.6-inch 1440p 165Hz",
    },
    reviews: [
      {
        id: 3,
        userId: 3,
        username: "GamerPro",
        rating: 5,
        comment: "This beast handles all my games at max settings. The 165Hz display is butter smooth!",
        date: "2023-05-20",
      },
      {
        id: 4,
        userId: 4,
        username: "StreamerX",
        rating: 4,
        comment: "Great for gaming and streaming. Wish it had better battery life, but that's expected for a gaming laptop.",
        date: "2023-06-10",
      },
    ],
    tags: ["gaming", "high-performance", "RTX graphics", "AMD Ryzen"],
  },
  {
    id: 3,
    name: "StudentBook Air",
    description: "Affordable and portable laptop for students",
    price: 699.99,
    image: "/placeholder.svg?height=200&width=300",
    specs: {
      processor: "Intel Core i5-1135G7",
      ram: "8GB DDR4",
      storage: "256GB NVMe SSD",
      display: "13.3-inch 1080p IPS",
    },
    reviews: [
      {
        id: 5,
        userId: 5,
        username: "CollegeStudent101",
        rating: 5,
        comment: "Perfect for my college needs. Lightweight, good battery life, and handles all my coursework apps well.",
        date: "2023-05-25",
      },
      {
        id: 6,
        userId: 6,
        username: "BudgetBuyer",
        rating: 4,
        comment: "Great value for the price. Wish it had more storage, but overall very satisfied.",
        date: "2023-06-15",
      },
    ],
    tags: ["student", "affordable", "portable", "budget"],
  },
  {
    id: 4,
    name: "CreatorStation Pro",
    description: "Powerful laptop for content creators and designers",
    price: 2299.99,
    image: "/placeholder.svg?height=200&width=300",
    specs: {
      processor: "Intel Core i9-11900H",
      ram: "64GB DDR4",
      storage: "2TB NVMe SSD",
      display: "17-inch 4K OLED",
    },
    reviews: [
      {
        id: 7,
        userId: 7,
        username: "DesignPro",
        rating: 5,
        comment: "This laptop is a powerhouse! Handles my 3D rendering and video editing tasks with ease.",
        date: "2023-05-30",
      },
      {
        id: 8,
        userId: 8,
        username: "ContentCreator",
        rating: 4,
        comment: "The 4K OLED display is stunning. Great performance, but it's quite heavy to carry around.",
        date: "2023-06-20",
      },
    ],
    tags: ["creator", "designer", "powerful", "4K OLED"],
  },
];

